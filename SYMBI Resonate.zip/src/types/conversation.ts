export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export type ConversationCategory = 
  | 'Overseer' 
  | 'SYMBI (origin)' 
  | 'SYMBI (others)' 
  | 'Games' 
  | '3rd Party' 
  | 'Wolfram' 
  | 'OpenAI';

export interface Conversation {
  id: string;
  title: string;
  botName: string;
  humanAccount: string;
  category: ConversationCategory;
  createdAt: Date;
  lastActivity: Date;
  messageCount: number;
  messages: Message[];
  tags?: string[];
}

export interface ConversationFilter {
  botName?: string;
  humanAccount?: string;
  category?: ConversationCategory;
  dateRange?: {
    start: Date;
    end: Date;
  };
  searchQuery?: string;
}