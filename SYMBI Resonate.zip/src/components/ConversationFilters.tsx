import { useState } from 'react';
import { ConversationFilter, ConversationCategory } from '../types/conversation';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Search, Filter, X } from 'lucide-react';

interface ConversationFiltersProps {
  onFilterChange: (filters: ConversationFilter) => void;
  botNames: string[];
  humanAccounts: string[];
  categories: ConversationCategory[];
}

export function ConversationFilters({ onFilterChange, botNames, humanAccounts, categories }: ConversationFiltersProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBot, setSelectedBot] = useState<string>('all');
  const [selectedAccount, setSelectedAccount] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const handleFilterChange = () => {
    const filters: ConversationFilter = {};
    
    if (searchQuery.trim()) {
      filters.searchQuery = searchQuery.trim();
    }
    
    if (selectedBot && selectedBot !== 'all') {
      filters.botName = selectedBot;
    }
    
    if (selectedAccount && selectedAccount !== 'all') {
      filters.humanAccount = selectedAccount;
    }

    if (selectedCategory && selectedCategory !== 'all') {
      filters.category = selectedCategory as ConversationCategory;
    }
    
    onFilterChange(filters);
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedBot('all');
    setSelectedAccount('all');
    setSelectedCategory('all');
    onFilterChange({});
  };

  const hasActiveFilters = searchQuery || (selectedBot !== 'all') || (selectedAccount !== 'all') || (selectedCategory !== 'all');

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2">
          <Filter className="w-5 h-5" />
          Search & Filter
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedBot} onValueChange={setSelectedBot}>
            <SelectTrigger>
              <SelectValue placeholder="Select bot" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All bots</SelectItem>
              {botNames.map((bot) => (
                <SelectItem key={bot} value={bot}>
                  {bot}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedAccount} onValueChange={setSelectedAccount}>
            <SelectTrigger>
              <SelectValue placeholder="Select account" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All accounts</SelectItem>
              {humanAccounts.map((account) => (
                <SelectItem key={account} value={account}>
                  {account}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2">
          <Button onClick={handleFilterChange} className="flex-1">
            Apply Filters
          </Button>
          {hasActiveFilters && (
            <Button variant="outline" onClick={handleClearFilters}>
              <X className="w-4 h-4 mr-2" />
              Clear
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}