import { useState, useRef } from 'react';
import { ConversationCategory } from '../types/conversation';
import { HTMLConversationParser } from '../utils/htmlParser';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Upload, FileText, Check, X, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface FileProcessingResult {
  fileName: string;
  status: 'success' | 'error' | 'processing';
  error?: string;
  messageCount?: number;
  title?: string;
}

interface HTMLUploaderProps {
  categories: ConversationCategory[];
  onConversationsImported: (conversations: any[]) => void;
}

export function HTMLUploader({ categories, onConversationsImported }: HTMLUploaderProps) {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [defaultCategory, setDefaultCategory] = useState<ConversationCategory>('SYMBI (others)');
  const [customBotName, setCustomBotName] = useState('');
  const [customHumanAccount, setCustomHumanAccount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingResults, setProcessingResults] = useState<FileProcessingResult[]>([]);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const htmlFiles = files.filter(file => 
      file.type === 'text/html' || file.name.toLowerCase().endsWith('.html')
    );
    setSelectedFiles(htmlFiles);
    setProcessingResults([]);
  };

  const removeFile = (index: number) => {
    setSelectedFiles(files => files.filter((_, i) => i !== index));
  };

  const processFiles = async () => {
    if (selectedFiles.length === 0) return;

    setIsProcessing(true);
    setProgress(0);
    const results: FileProcessingResult[] = [];
    const importedConversations: any[] = [];

    for (let i = 0; i < selectedFiles.length; i++) {
      const file = selectedFiles[i];
      const currentResult: FileProcessingResult = {
        fileName: file.name,
        status: 'processing'
      };
      
      setProcessingResults([...results, currentResult]);

      try {
        const htmlContent = await file.text();
        const parsedData = HTMLConversationParser.parseHTMLFile(htmlContent, file.name);
        
        if (parsedData && parsedData.messages.length > 0) {
          // Apply custom overrides if provided
          if (customBotName) {
            parsedData.botName = customBotName;
          }
          if (customHumanAccount) {
            parsedData.humanAccount = customHumanAccount;
          }

          const conversation = HTMLConversationParser.convertToConversation(
            parsedData,
            defaultCategory,
            file.name
          );

          importedConversations.push(conversation);
          
          currentResult.status = 'success';
          currentResult.messageCount = parsedData.messages.length;
          currentResult.title = parsedData.title;
        } else {
          currentResult.status = 'error';
          currentResult.error = 'No conversation data found in HTML file';
        }
      } catch (error) {
        currentResult.status = 'error';
        currentResult.error = error instanceof Error ? error.message : 'Unknown error';
      }

      results.push(currentResult);
      setProcessingResults([...results]);
      setProgress(((i + 1) / selectedFiles.length) * 100);
    }

    if (importedConversations.length > 0) {
      onConversationsImported(importedConversations);
    }

    setIsProcessing(false);
  };

  const resetUploader = () => {
    setSelectedFiles([]);
    setProcessingResults([]);
    setProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const successCount = processingResults.filter(r => r.status === 'success').length;
  const errorCount = processingResults.filter(r => r.status === 'error').length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="w-5 h-5" />
          Import HTML Conversations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* File Selection */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="file-upload">Select HTML Files</Label>
            <Input
              ref={fileInputRef}
              id="file-upload"
              type="file"
              multiple
              accept=".html,text/html"
              onChange={handleFileSelect}
              className="mt-1"
            />
          </div>

          {selectedFiles.length > 0 && (
            <div className="space-y-2">
              <Label>Selected Files ({selectedFiles.length})</Label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {selectedFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      <span className="text-sm truncate">{file.name}</span>
                      <Badge variant="outline" className="text-xs">
                        {(file.size / 1024).toFixed(1)} KB
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(index)}
                      disabled={isProcessing}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Configuration */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label>Default Category</Label>
            <Select value={defaultCategory} onValueChange={(value: ConversationCategory) => setDefaultCategory(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="bot-name">Bot Name Override (optional)</Label>
            <Input
              id="bot-name"
              value={customBotName}
              onChange={(e) => setCustomBotName(e.target.value)}
              placeholder="e.g., SYMBI-Custom"
            />
          </div>

          <div>
            <Label htmlFor="human-account">Human Account Override (optional)</Label>
            <Input
              id="human-account"
              value={customHumanAccount}
              onChange={(e) => setCustomHumanAccount(e.target.value)}
              placeholder="e.g., user@symbi.world"
            />
          </div>
        </div>

        {/* Processing */}
        {selectedFiles.length > 0 && (
          <div className="space-y-4">
            <div className="flex gap-2">
              <Button 
                onClick={processFiles} 
                disabled={isProcessing}
                className="flex-1"
              >
                {isProcessing ? 'Processing...' : `Import ${selectedFiles.length} File${selectedFiles.length > 1 ? 's' : ''}`}
              </Button>
              <Button variant="outline" onClick={resetUploader} disabled={isProcessing}>
                Reset
              </Button>
            </div>

            {isProcessing && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Processing files...</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} />
              </div>
            )}
          </div>
        )}

        {/* Results */}
        {processingResults.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <h4 className="font-medium">Import Results</h4>
              {successCount > 0 && (
                <Badge variant="default" className="bg-green-100 text-green-800">
                  <Check className="w-3 h-3 mr-1" />
                  {successCount} Success
                </Badge>
              )}
              {errorCount > 0 && (
                <Badge variant="destructive">
                  <X className="w-3 h-3 mr-1" />
                  {errorCount} Failed
                </Badge>
              )}
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto">
              {processingResults.map((result, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded">
                  <div className="flex items-center gap-2">
                    {result.status === 'success' && <Check className="w-4 h-4 text-green-500" />}
                    {result.status === 'error' && <X className="w-4 h-4 text-red-500" />}
                    {result.status === 'processing' && (
                      <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    )}
                    <div>
                      <div className="font-medium text-sm">{result.fileName}</div>
                      {result.status === 'success' && (
                        <div className="text-xs text-muted-foreground">
                          {result.messageCount} messages • {result.title}
                        </div>
                      )}
                      {result.status === 'error' && (
                        <div className="text-xs text-red-600">{result.error}</div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {successCount > 0 && !isProcessing && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Successfully imported {successCount} conversation{successCount > 1 ? 's' : ''}. 
                  They will appear in your archive with the "{defaultCategory}" category and "imported" tag.
                </AlertDescription>
              </Alert>
            )}
          </div>
        )}

      </CardContent>
    </Card>
  );
}