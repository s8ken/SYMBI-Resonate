import { useState, useMemo } from 'react';
import { Conversation, ConversationFilter } from '../types/conversation';
import { ConversationCard } from './ConversationCard';
import { ConversationDetail } from './ConversationDetail';
import { ConversationFilters } from './ConversationFilters';
import { HTMLUploader } from './HTMLUploader';
import { mockConversations, getBots, getHumanAccounts, getCategories, getCategoryStats } from '../utils/mockData';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Archive, BarChart3, Upload, Plus } from 'lucide-react';

type SortOption = 'date-desc' | 'date-asc' | 'messages-desc' | 'title-asc' | 'category-asc';

export function ConversationArchive() {
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [filters, setFilters] = useState<ConversationFilter>({});
  const [sortBy, setSortBy] = useState<SortOption>('date-desc');
  const [importedConversations, setImportedConversations] = useState<Conversation[]>([]);
  const [showUploader, setShowUploader] = useState(false);

  // Combine mock data with imported conversations
  const allConversations = [...mockConversations, ...importedConversations];

  const handleImportedConversations = (newConversations: Conversation[]) => {
    setImportedConversations(prev => [...prev, ...newConversations]);
    setShowUploader(false);
  };

  const filteredAndSortedConversations = useMemo(() => {
    let filtered = allConversations.filter((conversation) => {
      if (filters.botName && conversation.botName !== filters.botName) {
        return false;
      }
      
      if (filters.humanAccount && conversation.humanAccount !== filters.humanAccount) {
        return false;
      }

      if (filters.category && conversation.category !== filters.category) {
        return false;
      }
      
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        return (
          conversation.title.toLowerCase().includes(query) ||
          conversation.botName.toLowerCase().includes(query) ||
          conversation.humanAccount.toLowerCase().includes(query) ||
          conversation.category.toLowerCase().includes(query) ||
          (conversation.tags && conversation.tags.some(tag => tag.toLowerCase().includes(query)))
        );
      }
      
      return true;
    });

    // Sort conversations
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'date-desc':
          return b.createdAt.getTime() - a.createdAt.getTime();
        case 'date-asc':
          return a.createdAt.getTime() - b.createdAt.getTime();
        case 'messages-desc':
          return b.messageCount - a.messageCount;
        case 'title-asc':
          return a.title.localeCompare(b.title);
        case 'category-asc':
          return a.category.localeCompare(b.category);
        default:
          return 0;
      }
    });

    return filtered;
  }, [filters, sortBy, allConversations]);

  const totalMessages = allConversations.reduce((sum, conv) => sum + conv.messageCount, 0);
  
  // Recalculate category stats to include imported conversations
  const categoryStats = getCategories().map(category => ({
    category,
    count: allConversations.filter(conv => conv.category === category).length
  }));

  // Get unique bot names and accounts including imported ones
  const allBotNames = Array.from(new Set(allConversations.map(conv => conv.botName)));
  const allHumanAccounts = Array.from(new Set(allConversations.map(conv => conv.humanAccount)));

  if (selectedConversation) {
    return (
      <ConversationDetail
        conversation={selectedConversation}
        onBack={() => setSelectedConversation(null)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Archive className="w-6 h-6" />
                Symbi Conversation Archive
              </CardTitle>
              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mt-2">
                <div className="flex items-center gap-1">
                  <Badge variant="outline">{allConversations.length} conversations</Badge>
                </div>
                <div className="flex items-center gap-1">
                  <Badge variant="outline">{totalMessages} total messages</Badge>
                </div>
                <div className="flex items-center gap-1">
                  <Badge variant="outline">{allBotNames.length} bots</Badge>
                </div>
                {importedConversations.length > 0 && (
                  <div className="flex items-center gap-1">
                    <Badge variant="secondary">
                      {importedConversations.length} imported
                    </Badge>
                  </div>
                )}
              </div>
            </div>
            <Button onClick={() => setShowUploader(!showUploader)} variant="outline">
              <Plus className="w-4 h-4 mr-2" />
              Import HTML
            </Button>
          </div>
        </CardHeader>
      </Card>

      {showUploader && (
        <HTMLUploader
          categories={getCategories()}
          onConversationsImported={handleImportedConversations}
        />
      )}

      <Tabs defaultValue="browse" className="space-y-6">
        <TabsList>
          <TabsTrigger value="browse">Browse Conversations</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
        </TabsList>

        <TabsContent value="stats" className="space-y-6">
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Category Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
                {categoryStats.map(({ category, count }) => (
                  <div key={category} className="text-center p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-primary">{count}</div>
                    <div className="text-xs text-muted-foreground truncate" title={category}>
                      {category}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Bots by Conversations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {allBotNames
                    .map(bot => ({
                      bot,
                      count: allConversations.filter(conv => conv.botName === bot).length
                    }))
                    .sort((a, b) => b.count - a.count)
                    .slice(0, 5)
                    .map(({ bot, count }) => (
                      <div key={bot} className="flex justify-between items-center">
                        <span className="text-sm truncate">{bot}</span>
                        <Badge variant="outline">{count}</Badge>
                      </div>
                    ))
                  }
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Active Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {allHumanAccounts
                    .map(account => ({
                      account,
                      count: allConversations.filter(conv => conv.humanAccount === account).length
                    }))
                    .sort((a, b) => b.count - a.count)
                    .slice(0, 5)
                    .map(({ account, count }) => (
                      <div key={account} className="flex justify-between items-center">
                        <span className="text-sm truncate">{account}</span>
                        <Badge variant="outline">{count}</Badge>
                      </div>
                    ))
                  }
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="browse" className="space-y-6">
          <ConversationFilters
            onFilterChange={setFilters}
            botNames={allBotNames}
            humanAccounts={allHumanAccounts}
            categories={getCategories()}
          />

          <Card>
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle>
                  Conversations ({filteredAndSortedConversations.length})
                </CardTitle>
                <Select value={sortBy} onValueChange={(value: SortOption) => setSortBy(value)}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date-desc">Newest First</SelectItem>
                    <SelectItem value="date-asc">Oldest First</SelectItem>
                    <SelectItem value="messages-desc">Most Messages</SelectItem>
                    <SelectItem value="title-asc">Title A-Z</SelectItem>
                    <SelectItem value="category-asc">Category A-Z</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredAndSortedConversations.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Archive className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No conversations found matching your criteria.</p>
                  {allConversations.length === 0 && (
                    <Button 
                      onClick={() => setShowUploader(true)} 
                      variant="outline" 
                      className="mt-4"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Import HTML Conversations
                    </Button>
                  )}
                </div>
              ) : (
                <div className="grid gap-4">
                  {filteredAndSortedConversations.map((conversation) => (
                    <ConversationCard
                      key={conversation.id}
                      conversation={conversation}
                      onClick={setSelectedConversation}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}