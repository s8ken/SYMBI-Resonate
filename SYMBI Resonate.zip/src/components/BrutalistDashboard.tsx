import { useState, useMemo } from 'react';
import { Conversation } from '../types/conversation';
import { Button } from './ui/button';
import { calculateConversationMetrics, formatNumber, formatWordCount, getTopBots } from '../utils/conversationMetrics';
import { Database, FileText, Bot, MessageSquare, Hash, TrendingUp, Archive, BarChart3 } from 'lucide-react';

interface DashboardMetric {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  description: string;
}

interface BrutalistDashboardProps {
  conversations: Conversation[];
  onNavigateToArchive: () => void;
  onNavigateToUpload: () => void;
}

export function BrutalistDashboard({ conversations, onNavigateToArchive, onNavigateToUpload }: BrutalistDashboardProps) {
  const [activeMetric, setActiveMetric] = useState<string | null>(null);

  const metrics = useMemo(() => {
    const calculatedMetrics = calculateConversationMetrics(conversations);
    const topBots = getTopBots(calculatedMetrics.botDistribution, 3);

    const dashboardMetrics: DashboardMetric[] = [
      {
        label: 'TOTAL DOCS',
        value: formatNumber(calculatedMetrics.totalConversations),
        icon: <FileText className="w-8 h-8" />,
        color: 'brutalist-card-yellow',
        description: `${calculatedMetrics.totalConversations} conversation documents uploaded`
      },
      {
        label: 'WORD COUNT',
        value: formatWordCount(calculatedMetrics.totalWords),
        icon: <Hash className="w-8 h-8" />,
        color: 'brutalist-card-cyan',
        description: `${formatWordCount(calculatedMetrics.totalWords)} total words across all conversations`
      },
      {
        label: 'TOTAL MESSAGES',
        value: formatNumber(calculatedMetrics.totalMessages),
        icon: <MessageSquare className="w-8 h-8" />,
        color: 'brutalist-card-magenta',
        description: `${calculatedMetrics.totalMessages.toLocaleString()} individual messages`
      },
      {
        label: 'AI TYPES',
        value: Object.keys(calculatedMetrics.botDistribution).length,
        icon: <Bot className="w-8 h-8" />,
        color: 'brutalist-card-lime',
        description: `${Object.keys(calculatedMetrics.botDistribution).length} different AI systems`
      },
      {
        label: 'AVG MSGS/CONV',
        value: calculatedMetrics.averageMessagesPerConversation,
        icon: <TrendingUp className="w-8 h-8" />,
        color: 'brutalist-card-orange',
        description: `${calculatedMetrics.averageMessagesPerConversation} average messages per conversation`
      },
      {
        label: 'CATEGORIES',
        value: Object.keys(calculatedMetrics.categoryDistribution).length,
        icon: <BarChart3 className="w-8 h-8" />,
        color: 'brutalist-card-red',
        description: `${Object.keys(calculatedMetrics.categoryDistribution).length} conversation categories`
      }
    ];

    return { 
      dashboardMetrics, 
      botCounts: calculatedMetrics.botDistribution, 
      topBots, 
      categoryStats: calculatedMetrics.categoryDistribution 
    };
  }, [conversations]);

  return (
    <div className="space-y-8 p-8 bg-white">
      {/* Header */}
      <div className="brutalist-card p-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-6xl font-black brutalist-text mb-4">SYMBI.WORLD</h1>
            <p className="text-2xl font-bold">CONVERSATION ARCHIVE DASHBOARD</p>
            <p className="text-lg mt-2 text-gray-600">REAL-TIME ANALYTICS & METRICS</p>
          </div>
          <Database className="w-24 h-24" />
        </div>
      </div>

      {/* Main Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {metrics.dashboardMetrics.map((metric, index) => (
          <div
            key={metric.label}
            className={`${metric.color} p-8 cursor-pointer transition-all duration-300 hover:scale-105`}
            onMouseEnter={() => setActiveMetric(metric.label)}
            onMouseLeave={() => setActiveMetric(null)}
          >
            <div className="flex items-center justify-between mb-4">
              {metric.icon}
              <div className="text-right">
                <div className="text-4xl font-black brutalist-text">{metric.value}</div>
                <div className="text-lg font-bold brutalist-text">{metric.label}</div>
              </div>
            </div>
            {activeMetric === metric.label && (
              <div className="mt-4 text-sm font-medium">
                {metric.description}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* AI Types Breakdown */}
      {metrics.topBots.length > 0 && (
        <div className="brutalist-card-blue p-8">
          <h2 className="text-3xl font-black brutalist-text mb-6 text-white">TOP AI SYSTEMS</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {metrics.topBots.map(([botName, count], index) => (
              <div key={botName} className="bg-white brutalist-border p-6">
                <div className="text-3xl font-black text-black">{count}</div>
                <div className="text-lg font-bold brutalist-text text-black">{botName}</div>
                <div className="text-sm text-gray-600">CONVERSATIONS</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Category Distribution */}
      <div className="brutalist-card p-8">
        <h2 className="text-3xl font-black brutalist-text mb-6">CATEGORY BREAKDOWN</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {Object.entries(metrics.categoryStats).map(([category, count]) => (
            <div key={category} className="brutalist-border p-4 bg-gray-100">
              <div className="text-2xl font-black">{count}</div>
              <div className="text-sm font-bold brutalist-text truncate" title={category}>
                {category}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col md:flex-row gap-6">
        <button 
          onClick={onNavigateToArchive}
          className="brutalist-button flex-1 flex items-center justify-center gap-4"
        >
          <Archive className="w-6 h-6" />
          <span className="text-xl font-black">VIEW ARCHIVE</span>
        </button>
        
        <button 
          onClick={onNavigateToUpload}
          className="brutalist-button flex-1 flex items-center justify-center gap-4 bg-brutalist-yellow"
        >
          <FileText className="w-6 h-6" />
          <span className="text-xl font-black">IMPORT HTML</span>
        </button>
      </div>

      {/* System Status */}
      <div className="brutalist-card-lime p-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-lg font-black brutalist-text">SYSTEM STATUS: OPERATIONAL</div>
            <div className="text-sm">Last updated: {new Date().toLocaleString()}</div>
          </div>
          <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
        </div>
      </div>
    </div>
  );
}