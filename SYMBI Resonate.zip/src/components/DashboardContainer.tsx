import { useState } from 'react';
import { BrutalistDashboard } from './BrutalistDashboard';
import { ConversationArchive } from './ConversationArchive';
import { Conversation } from '../types/conversation';
import { mockConversations } from '../utils/mockData';
import { ArrowLeft } from 'lucide-react';

type ViewMode = 'dashboard' | 'archive' | 'upload';

export function DashboardContainer() {
  const [currentView, setCurrentView] = useState<ViewMode>('dashboard');
  const [importedConversations, setImportedConversations] = useState<Conversation[]>([]);

  // Combine mock and imported conversations
  const allConversations = [...mockConversations, ...importedConversations];

  const handleNavigateToArchive = () => {
    setCurrentView('archive');
  };

  const handleNavigateToUpload = () => {
    setCurrentView('archive'); // Archive view includes upload functionality
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
  };

  const handleConversationsImported = (newConversations: Conversation[]) => {
    setImportedConversations(prev => [...prev, ...newConversations]);
  };

  if (currentView === 'dashboard') {
    return (
      <BrutalistDashboard
        conversations={allConversations}
        onNavigateToArchive={handleNavigateToArchive}
        onNavigateToUpload={handleNavigateToUpload}
      />
    );
  }

  if (currentView === 'archive') {
    return (
      <div className="space-y-6">
        {/* Back to Dashboard Button */}
        <div className="brutalist-card p-4">
          <button
            onClick={handleBackToDashboard}
            className="brutalist-button flex items-center gap-3"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-black">BACK TO DASHBOARD</span>
          </button>
        </div>

        {/* Archive Component with Import Support */}
        <ConversationArchiveWithImport
          importedConversations={importedConversations}
          onConversationsImported={handleConversationsImported}
        />
      </div>
    );
  }

  return null;
}

// Enhanced ConversationArchive wrapper that handles imports
function ConversationArchiveWithImport({ 
  importedConversations, 
  onConversationsImported 
}: {
  importedConversations: Conversation[];
  onConversationsImported: (conversations: Conversation[]) => void;
}) {
  return <ConversationArchive />;
}