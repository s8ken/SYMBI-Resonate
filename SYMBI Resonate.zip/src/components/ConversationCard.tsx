import { Conversation } from '../types/conversation';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { MessageCircle, Calendar, User, Bot, Tag } from 'lucide-react';

interface ConversationCardProps {
  conversation: Conversation;
  onClick: (conversation: Conversation) => void;
}

const getCategoryColor = (category: string) => {
  const colors = {
    'Overseer': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    'SYMBI (origin)': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    'SYMBI (others)': 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
    'Games': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    '3rd Party': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    'Wolfram': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
    'OpenAI': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
  };
  return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
};

export function ConversationCard({ conversation, onClick }: ConversationCardProps) {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <Card 
      className="cursor-pointer transition-all hover:shadow-md hover:border-primary/20"
      onClick={() => onClick(conversation)}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <h3 className="font-medium truncate pr-2">{conversation.title}</h3>
          <div className="flex items-center gap-2 shrink-0">
            <Badge 
              className={`${getCategoryColor(conversation.category)} border-0`}
            >
              <Tag className="w-3 h-3 mr-1" />
              {conversation.category}
            </Badge>
            <Badge variant="secondary">
              <MessageCircle className="w-3 h-3 mr-1" />
              {conversation.messageCount}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Bot className="w-4 h-4" />
            <span className="truncate">{conversation.botName}</span>
          </div>
          <div className="flex items-center gap-1">
            <User className="w-4 h-4" />
            <span className="truncate">{conversation.humanAccount}</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-1 text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span>{formatDate(conversation.createdAt)}</span>
          </div>
          {conversation.lastActivity > conversation.createdAt && (
            <span className="text-xs text-muted-foreground">
              Last: {formatDate(conversation.lastActivity)}
            </span>
          )}
        </div>

        {conversation.tags && conversation.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {conversation.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
            {conversation.tags.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{conversation.tags.length - 3}
              </Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}