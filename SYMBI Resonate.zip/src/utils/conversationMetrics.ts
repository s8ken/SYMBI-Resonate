import { Conversation } from '../types/conversation';

export interface ConversationMetrics {
  totalConversations: number;
  totalMessages: number;
  totalWords: number;
  averageMessagesPerConversation: number;
  averageWordsPerConversation: number;
  botDistribution: Record<string, number>;
  categoryDistribution: Record<string, number>;
  timeRangeStats: {
    oldestConversation: Date | null;
    newestConversation: Date | null;
    totalDays: number;
  };
}

export function calculateConversationMetrics(conversations: Conversation[]): ConversationMetrics {
  if (conversations.length === 0) {
    return {
      totalConversations: 0,
      totalMessages: 0,
      totalWords: 0,
      averageMessagesPerConversation: 0,
      averageWordsPerConversation: 0,
      botDistribution: {},
      categoryDistribution: {},
      timeRangeStats: {
        oldestConversation: null,
        newestConversation: null,
        totalDays: 0
      }
    };
  }

  const totalMessages = conversations.reduce((sum, conv) => sum + conv.messageCount, 0);
  
  const totalWords = conversations.reduce((total, conv) => {
    if (!conv.messages) return total;
    
    return total + conv.messages.reduce((messageTotal, message) => {
      // Count words in message content
      const wordCount = message.content
        .trim()
        .split(/\s+/)
        .filter(word => word.length > 0).length;
      return messageTotal + wordCount;
    }, 0);
  }, 0);

  const botDistribution = conversations.reduce((acc, conv) => {
    acc[conv.botName] = (acc[conv.botName] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const categoryDistribution = conversations.reduce((acc, conv) => {
    acc[conv.category] = (acc[conv.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Calculate time range
  const dates = conversations.map(conv => conv.createdAt);
  const oldestConversation = new Date(Math.min(...dates.map(d => d.getTime())));
  const newestConversation = new Date(Math.max(...dates.map(d => d.getTime())));
  const totalDays = Math.ceil((newestConversation.getTime() - oldestConversation.getTime()) / (1000 * 60 * 60 * 24));

  return {
    totalConversations: conversations.length,
    totalMessages,
    totalWords,
    averageMessagesPerConversation: Math.round(totalMessages / conversations.length),
    averageWordsPerConversation: Math.round(totalWords / conversations.length),
    botDistribution,
    categoryDistribution,
    timeRangeStats: {
      oldestConversation,
      newestConversation,
      totalDays: Math.max(totalDays, 1) // Ensure at least 1 day
    }
  };
}

export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
}

export function formatWordCount(words: number): string {
  return words.toLocaleString();
}

export function getTopBots(botDistribution: Record<string, number>, limit: number = 5) {
  return Object.entries(botDistribution)
    .sort(([,a], [,b]) => b - a)
    .slice(0, limit);
}

export function getTopCategories(categoryDistribution: Record<string, number>, limit: number = 5) {
  return Object.entries(categoryDistribution)
    .sort(([,a], [,b]) => b - a)
    .slice(0, limit);
}