import { Conversation, ConversationCategory, Message } from '../types/conversation';

interface ParsedConversationData {
  title?: string;
  botName?: string;
  humanAccount?: string;
  messages: Array<{
    role: 'user' | 'assistant';
    content: string;
    timestamp?: Date;
  }>;
  metadata?: {
    createdAt?: Date;
    lastActivity?: Date;
    platform?: string;
  };
}

export class HTMLConversationParser {
  
  static parseHTMLFile(htmlContent: string, fileName: string): ParsedConversationData | null {
    try {
      // Create a DOM parser
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlContent, 'text/html');
      
      // Try different parsing strategies based on common HTML conversation formats
      const strategies = [
        this.parseChatGPTFormat,
        this.parseClaudeFormat,
        this.parseGenericChatFormat,
        this.parseCustomFormat
      ];
      
      for (const strategy of strategies) {
        const result = strategy(doc, fileName);
        if (result && result.messages.length > 0) {
          return result;
        }
      }
      
      return null;
    } catch (error) {
      console.error('Error parsing HTML:', error);
      return null;
    }
  }
  
  // Parser for ChatGPT export format
  static parseChatGPTFormat(doc: Document, fileName: string): ParsedConversationData | null {
    const messages: ParsedConversationData['messages'] = [];
    
    // Look for ChatGPT-style conversation elements
    const messageElements = doc.querySelectorAll('[data-message-author-role], .conversation-turn, .message');
    
    messageElements.forEach(element => {
      const role = element.getAttribute('data-message-author-role') || 
                   (element.textContent?.includes('You:') ? 'user' : 'assistant');
      
      const content = this.extractTextContent(element);
      if (content.trim()) {
        messages.push({
          role: role === 'user' ? 'user' : 'assistant',
          content: content.trim(),
          timestamp: this.extractTimestamp(element)
        });
      }
    });
    
    return messages.length > 0 ? {
      title: doc.title || fileName.replace('.html', ''),
      botName: 'ChatGPT',
      messages
    } : null;
  }
  
  // Parser for Claude export format
  static parseClaudeFormat(doc: Document, fileName: string): ParsedConversationData | null {
    const messages: ParsedConversationData['messages'] = [];
    
    // Look for Claude-style elements
    const humanMessages = doc.querySelectorAll('.human-message, [data-role="human"]');
    const assistantMessages = doc.querySelectorAll('.assistant-message, [data-role="assistant"]');
    
    const allMessages = [...humanMessages, ...assistantMessages].sort((a, b) => {
      const aIndex = Array.from(a.parentElement?.children || []).indexOf(a);
      const bIndex = Array.from(b.parentElement?.children || []).indexOf(b);
      return aIndex - bIndex;
    });
    
    allMessages.forEach(element => {
      const isHuman = element.classList.contains('human-message') || 
                      element.getAttribute('data-role') === 'human';
      
      const content = this.extractTextContent(element);
      if (content.trim()) {
        messages.push({
          role: isHuman ? 'user' : 'assistant',
          content: content.trim(),
          timestamp: this.extractTimestamp(element)
        });
      }
    });
    
    return messages.length > 0 ? {
      title: doc.title || fileName.replace('.html', ''),
      botName: 'Claude',
      messages
    } : null;
  }
  
  // Generic chat format parser
  static parseGenericChatFormat(doc: Document, fileName: string): ParsedConversationData | null {
    const messages: ParsedConversationData['messages'] = [];
    
    // Look for common chat patterns
    const chatElements = doc.querySelectorAll('div, p, li').forEach(element => {
      const text = element.textContent || '';
      
      // Look for patterns like "User:", "Human:", "Assistant:", "AI:", etc.
      const userPatterns = /^(User|Human|You):?\s*/i;
      const botPatterns = /^(Assistant|AI|Bot|ChatGPT|Claude|GPT):?\s*/i;
      
      if (userPatterns.test(text)) {
        const content = text.replace(userPatterns, '').trim();
        if (content) {
          messages.push({
            role: 'user',
            content,
            timestamp: this.extractTimestamp(element)
          });
        }
      } else if (botPatterns.test(text)) {
        const content = text.replace(botPatterns, '').trim();
        if (content) {
          messages.push({
            role: 'assistant',
            content,
            timestamp: this.extractTimestamp(element)
          });
        }
      }
    });
    
    return messages.length > 0 ? {
      title: doc.title || fileName.replace('.html', ''),
      messages
    } : null;
  }
  
  // Custom format parser for unknown formats
  static parseCustomFormat(doc: Document, fileName: string): ParsedConversationData | null {
    const messages: ParsedConversationData['messages'] = [];
    
    // Extract all text content and try to identify conversation patterns
    const textContent = doc.body?.textContent || '';
    const lines = textContent.split('\n').filter(line => line.trim());
    
    let currentRole: 'user' | 'assistant' = 'user';
    let currentMessage = '';
    
    lines.forEach(line => {
      const trimmedLine = line.trim();
      
      // Try to detect role changes
      if (trimmedLine.toLowerCase().includes('user') || 
          trimmedLine.toLowerCase().includes('human') ||
          trimmedLine.toLowerCase().includes('you:')) {
        if (currentMessage) {
          messages.push({
            role: currentRole,
            content: currentMessage.trim()
          });
          currentMessage = '';
        }
        currentRole = 'user';
        currentMessage = trimmedLine.replace(/^(user|human|you):?\s*/i, '');
      } else if (trimmedLine.toLowerCase().includes('assistant') || 
                 trimmedLine.toLowerCase().includes('ai') ||
                 trimmedLine.toLowerCase().includes('bot')) {
        if (currentMessage) {
          messages.push({
            role: currentRole,
            content: currentMessage.trim()
          });
          currentMessage = '';
        }
        currentRole = 'assistant';
        currentMessage = trimmedLine.replace(/^(assistant|ai|bot):?\s*/i, '');
      } else if (trimmedLine) {
        currentMessage += (currentMessage ? '\n' : '') + trimmedLine;
      }
    });
    
    // Add the last message
    if (currentMessage) {
      messages.push({
        role: currentRole,
        content: currentMessage.trim()
      });
    }
    
    return messages.length > 0 ? {
      title: fileName.replace('.html', ''),
      messages
    } : null;
  }
  
  static extractTextContent(element: Element): string {
    // Remove script and style elements
    const clone = element.cloneNode(true) as Element;
    clone.querySelectorAll('script, style').forEach(el => el.remove());
    return clone.textContent || '';
  }
  
  static extractTimestamp(element: Element): Date | undefined {
    // Look for timestamp patterns in various formats
    const timeAttributes = ['data-timestamp', 'timestamp', 'datetime'];
    
    for (const attr of timeAttributes) {
      const value = element.getAttribute(attr);
      if (value) {
        const date = new Date(value);
        if (!isNaN(date.getTime())) {
          return date;
        }
      }
    }
    
    // Look for time elements
    const timeElement = element.querySelector('time');
    if (timeElement) {
      const datetime = timeElement.getAttribute('datetime') || timeElement.textContent;
      if (datetime) {
        const date = new Date(datetime);
        if (!isNaN(date.getTime())) {
          return date;
        }
      }
    }
    
    return undefined;
  }
  
  static convertToConversation(
    parsedData: ParsedConversationData, 
    category: ConversationCategory,
    fileName: string
  ): Conversation {
    const now = new Date();
    const messages: Message[] = parsedData.messages.map((msg, index) => ({
      id: `msg-${index}`,
      role: msg.role,
      content: msg.content,
      timestamp: msg.timestamp || new Date(now.getTime() - (parsedData.messages.length - index) * 60000)
    }));
    
    const firstTimestamp = messages[0]?.timestamp || now;
    const lastTimestamp = messages[messages.length - 1]?.timestamp || now;
    
    return {
      id: `imported-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      title: parsedData.title || fileName.replace('.html', ''),
      botName: parsedData.botName || 'Unknown Bot',
      humanAccount: parsedData.humanAccount || 'imported-user@symbi.world',
      category,
      createdAt: firstTimestamp,
      lastActivity: lastTimestamp,
      messageCount: messages.length,
      messages,
      tags: ['imported', 'html-source']
    };
  }
}