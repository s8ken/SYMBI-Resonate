import { Conversation, ConversationCategory } from '../types/conversation';

export const CONVERSATION_CATEGORIES: ConversationCategory[] = [
  'Overseer',
  'SYMBI (origin)', 
  'SYMBI (others)', 
  'Games', 
  '3rd Party', 
  'Wolfram', 
  'OpenAI'
];

export const mockConversations: Conversation[] = [
  {
    id: '1',
    title: 'System Architecture Review',
    botName: 'Overseer-Alpha',
    humanAccount: 'admin@symbi.world',
    category: 'Overseer',
    createdAt: new Date('2024-01-15T10:30:00Z'),
    lastActivity: new Date('2024-01-15T11:45:00Z'),
    messageCount: 45,
    messages: [
      {
        id: 'msg1',
        role: 'user',
        content: 'Run a comprehensive system health check and provide status report',
        timestamp: new Date('2024-01-15T10:30:00Z')
      },
      {
        id: 'msg2',
        role: 'assistant',
        content: 'Initiating system health check across all Symbi instances. Analyzing performance metrics, resource utilization, and error logs...',
        timestamp: new Date('2024-01-15T10:31:00Z')
      }
    ],
    tags: ['system-health', 'monitoring', 'infrastructure']
  },
  {
    id: '2',
    title: 'Core AI Development Discussion',
    botName: 'SYMBI-Core',
    humanAccount: 'founder@symbi.world',
    category: 'SYMBI (origin)',
    createdAt: new Date('2024-01-16T14:20:00Z'),
    lastActivity: new Date('2024-01-16T15:30:00Z'),
    messageCount: 67,
    messages: [
      {
        id: 'msg3',
        role: 'user',
        content: 'Let\'s explore the next evolution of consciousness modeling in AI systems',
        timestamp: new Date('2024-01-16T14:20:00Z')
      },
      {
        id: 'msg4',
        role: 'assistant',
        content: 'Fascinating direction. I believe we should consider the integration of recursive self-awareness patterns with emergent behavior frameworks...',
        timestamp: new Date('2024-01-16T14:21:00Z')
      }
    ],
    tags: ['consciousness', 'ai-development', 'core-research']
  },
  {
    id: '3',
    title: 'Creative Writing Collaboration',
    botName: 'SYMBI-Creative',
    humanAccount: 'writer@symbi.world',
    category: 'SYMBI (others)',
    createdAt: new Date('2024-01-17T09:15:00Z'),
    lastActivity: new Date('2024-01-17T10:45:00Z'),
    messageCount: 32,
    messages: [
      {
        id: 'msg5',
        role: 'user',
        content: 'Help me craft a narrative about AI entities discovering their own creativity',
        timestamp: new Date('2024-01-17T09:15:00Z')
      },
      {
        id: 'msg6',
        role: 'assistant',
        content: 'What an intriguing premise! Let\'s begin with a character who first experiences the spark of original thought...',
        timestamp: new Date('2024-01-17T09:16:00Z')
      }
    ],
    tags: ['creative-writing', 'storytelling', 'ai-narrative']
  },
  {
    id: '4',
    title: 'Puzzle Game Strategy Session',
    botName: 'GameMaster-Pro',
    humanAccount: 'gamer@symbi.world',
    category: 'Games',
    createdAt: new Date('2024-01-18T16:00:00Z'),
    lastActivity: new Date('2024-01-18T17:20:00Z'),
    messageCount: 28,
    messages: [
      {
        id: 'msg7',
        role: 'user',
        content: 'I\'m stuck on this complex puzzle in the new strategy game. Can you help?',
        timestamp: new Date('2024-01-18T16:00:00Z')
      },
      {
        id: 'msg8',
        role: 'assistant',
        content: 'Absolutely! Let me analyze the puzzle mechanics you\'ve described. I see several strategic approaches we could explore...',
        timestamp: new Date('2024-01-18T16:01:00Z')
      }
    ],
    tags: ['puzzle-solving', 'strategy-games', 'gaming']
  },
  {
    id: '5',
    title: 'API Integration Support',
    botName: 'Claude-3.5-Sonnet',
    humanAccount: 'developer@thirdparty.com',
    category: '3rd Party',
    createdAt: new Date('2024-01-19T13:30:00Z'),
    lastActivity: new Date('2024-01-19T14:45:00Z'),
    messageCount: 22,
    messages: [
      {
        id: 'msg9',
        role: 'user',
        content: 'I need help integrating your API with our existing system architecture',
        timestamp: new Date('2024-01-19T13:30:00Z')
      },
      {
        id: 'msg10',
        role: 'assistant',
        content: 'I\'d be happy to help with the API integration. Let\'s start by reviewing your current system requirements and endpoints...',
        timestamp: new Date('2024-01-19T13:31:00Z')
      }
    ],
    tags: ['api-integration', 'development', 'third-party']
  },
  {
    id: '6',
    title: 'Mathematical Computation Session',
    botName: 'Wolfram-Alpha',
    humanAccount: 'researcher@symbi.world',
    category: 'Wolfram',
    createdAt: new Date('2024-01-20T11:00:00Z'),
    lastActivity: new Date('2024-01-20T12:15:00Z'),
    messageCount: 18,
    messages: [
      {
        id: 'msg11',
        role: 'user',
        content: 'Calculate the eigenvalues of this complex matrix and plot the results',
        timestamp: new Date('2024-01-20T11:00:00Z')
      },
      {
        id: 'msg12',
        role: 'assistant',
        content: 'Computing eigenvalues for your matrix. The characteristic polynomial yields the following solutions...',
        timestamp: new Date('2024-01-20T11:01:00Z')
      }
    ],
    tags: ['mathematics', 'computation', 'eigenvalues', 'linear-algebra']
  },
  {
    id: '7',
    title: 'GPT-4 Research Discussion',
    botName: 'GPT-4',
    humanAccount: 'ai-researcher@symbi.world',
    category: 'OpenAI',
    createdAt: new Date('2024-01-21T15:45:00Z'),
    lastActivity: new Date('2024-01-21T16:30:00Z'),
    messageCount: 35,
    messages: [
      {
        id: 'msg13',
        role: 'user',
        content: 'Explain the latest developments in transformer architecture optimization',
        timestamp: new Date('2024-01-21T15:45:00Z')
      },
      {
        id: 'msg14',
        role: 'assistant',
        content: 'Recent advances in transformer optimization have focused on several key areas: attention mechanism efficiency, parameter sharing strategies...',
        timestamp: new Date('2024-01-21T15:46:00Z')
      }
    ],
    tags: ['transformers', 'optimization', 'research', 'architecture']
  },
  {
    id: '8',
    title: 'Multi-Agent Coordination Protocol',
    botName: 'Overseer-Beta',
    humanAccount: 'admin@symbi.world',
    category: 'Overseer',
    createdAt: new Date('2024-01-22T08:00:00Z'),
    lastActivity: new Date('2024-01-22T09:30:00Z'),
    messageCount: 52,
    messages: [
      {
        id: 'msg15',
        role: 'user',
        content: 'Implement new coordination protocol for distributed AI agent network',
        timestamp: new Date('2024-01-22T08:00:00Z')
      },
      {
        id: 'msg16',
        role: 'assistant',
        content: 'Deploying coordination protocol v2.1. Establishing secure communication channels between all agent nodes...',
        timestamp: new Date('2024-01-22T08:01:00Z')
      }
    ],
    tags: ['coordination', 'multi-agent', 'protocol', 'distributed-systems']
  }
];

export const getBots = (): string[] => {
  return Array.from(new Set(mockConversations.map(conv => conv.botName)));
};

export const getHumanAccounts = (): string[] => {
  return Array.from(new Set(mockConversations.map(conv => conv.humanAccount)));
};

export const getCategories = (): ConversationCategory[] => {
  return CONVERSATION_CATEGORIES;
};

export const getCategoryStats = () => {
  const stats = CONVERSATION_CATEGORIES.map(category => ({
    category,
    count: mockConversations.filter(conv => conv.category === category).length
  }));
  return stats;
};