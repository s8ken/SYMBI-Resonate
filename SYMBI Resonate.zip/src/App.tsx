import { DashboardContainer } from './components/DashboardContainer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <DashboardContainer />
      </div>
    </div>
  );
}