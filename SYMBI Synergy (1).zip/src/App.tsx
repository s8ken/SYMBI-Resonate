import { Dashboard } from "./components/Dashboard";

export default function App() {
  return <Dashboard />;
}